<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <?php echo $__env->yieldPushContent('meta-data'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <title id="parentLayoutPageTitle"><?php echo $__env->yieldContent('page-title'); ?> <?php echo e(config('app.name', 'Laravel')); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
    <meta content="Coderthemes" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">
    
    <!-- third party css -->
    <link href="<?php echo e(asset ('assets/css/vendor/fullcalendar.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- third party css end -->

    <!-- App css -->
    <link href="<?php echo e(asset ('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset ('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="light-style" />
    <link href="<?php echo e(asset ('assets/css/app-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="dark-style" />
    <!-- SweedAlert -->
    <link href="<?php echo e(asset('/assets/libs/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />
    
    <?php echo $__env->yieldPushContent('page-css'); ?>
</head>

<body class="loading"
    data-layout-config='{"leftSideBarTheme":"dark","layoutBoxed":false, "leftSidebarCondensed":false, "leftSidebarScrollable":false,"darkMode":false, "showRightSidebarOnStart": true}'>
    <!-- Begin page -->
    <div class="wrapper">
        <!-- ========== Left Sidebar Start ========== -->
        <div class="leftside-menu">
    
            <!-- LOGO -->
            <a href="/" class="logo text-center logo-light">
                <span class="logo-lg">
                    <img src="/assets/images/logo.png" alt="" height="50">
                </span>
                <span class="logo-sm">
                    <img src="/assets/images/logo_sm.png" alt="" height="16">
                </span>
            </a>

            <!-- LOGO -->
            <a href="/" class="logo text-center logo-dark">
                <span class="logo-lg">
                    <img src="assets/images/logo-dark.png" alt="" height="16">
                </span>
                <span class="logo-sm">
                    <img src="assets/images/logo_sm_dark.png" alt="" height="16">
                </span>
            </a>
    
            <div class="h-100" id="leftside-menu-container" data-simplebar>

                <!--- Sidemenu -->
                <ul class="side-nav">

                    <li class="side-nav-title side-nav-item"></li>

                    <li class="side-nav-item menuitem">
                        <a href="<?php echo e(route("super.admin.home")); ?>" aria-expanded="false" aria-controls="sidebarDashboards" class="side-nav-link">
                            <i class="uil-clipboard-alt"></i>
                            <span> Dashboard</span> 
                        </a>
                    </li>
                    <li class="side-nav-item menuitem">
                        <a href="<?php echo e(route("super.admin.userManagement")); ?>" aria-expanded="false" aria-controls="sidebarDashboards" class="side-nav-link">
                            <i class="uil-clipboard-alt"></i>
                            <span> Users Management </span>
                        </a>
                    </li>
                    <li class="side-nav-item menuitem">
                        <a href="#" aria-expanded="false" aria-controls="sidebarDashboards" class="side-nav-link">
                            <i class="mdi mdi-account-edit"></i>
                            <span> SPMS Management </span>
                        </a>
                    </li>

                </ul>

                <!-- Help Box -->
                <div class="help-box text-white text-center">
                    <img src="/assets/images/help-icon.svg" height="90" alt="Helper Icon Image" />
                    <h5 class="mt-3">Accomplishment Repository</h5>
                    <p class="mb-3">This web app is built for recording employees daily accomplishments.</p>
                </div>
                <!-- end Help Box -->
                <!-- End Sidebar -->

                <div class="clearfix"></div>

            </div>
            <!-- Sidebar -left -->

        </div>
        <!-- Left Sidebar End -->

        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->
        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <div class="navbar-custom">
                    <ul class="list-unstyled topbar-menu float-end mb-0">

                        <li class="dropdown notification-list">
                            <a class="nav-link dropdown-toggle nav-user arrow-none me-0" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false"
                                aria-expanded="false">
                                <span class="account-user-avatar"> 
                                    <img src="/assets/images/itu-logo.png" alt="user-image" class="rounded-circle">
                                </span>
                                <span>
                                    <span class="account-user-name"><?php echo e(Auth::user()->username); ?></span>
                                    <span class="account-position">ITU Office</span>
                                </span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end dropdown-menu-animated topbar-dropdown-menu profile-dropdown">
                                <!-- item-->
                                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();" class="dropdown-item notify-item">
                                    <i class="mdi mdi-logout me-1"></i>
                                    <span>Logout</span>
                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                            </div>
                        </li>

                    </ul>
                    <button class="button-menu-mobile open-left">
                        <i class="mdi mdi-menu"></i>
                    </button>
                </div>
                <!-- end Topbar -->
                <?php echo $__env->yieldContent('content'); ?>
                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                <script>document.write(new Date().getFullYear())</script> © Information Technology Unit
                            </div>
                            <div class="col-md-6">
                                <div class="text-md-end footer-links d-none d-md-block">
                                    <a href="javascript: void(0);">About</a>
                                    <a href="javascript: void(0);">Support</a>
                                    <a href="javascript: void(0);">Contact Us</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->
            </div>
        </div>

    </div>
    <!-- bundle -->
    
    <script src="<?php echo e(asset ('assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset ('assets/js/app.min.js')); ?>"></script>
    <script src="<?php echo e(asset ('assets/js/vendor/fullcalendar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/libs/jquery/jquery.min.js')); ?>"></script>
    <script >
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    </script>
    <!-- SweetAlert -->
    <script src="<?php echo e(asset('/assets/libs/sweetalert2/sweetalert.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('page-scripts'); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\accomplishmentRepo\resources\views/layouts/app.blade.php ENDPATH**/ ?>