<?php $__env->startPush('page-css'); ?>
    <link href="<?php echo e(asset('assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-4">
        <div class="card overflow-hidden">
            <div class="bg-primary bg-soft">
                <div class="row">
                    <div class="col-12">
                        <div class="text-primary p-3">
                            <h4 class="text-primary fw-bold"><?php echo e($customer->fullname); ?></h4>
                            <p class="p-0 m-0">Account #: <span class="fw-bold"><?php echo e($customer->AccountNumber); ?></span></p>
                            <p class="p-0 m-0">Address: <span class="fw-bold"><?php echo e($customer->Address); ?></span></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body pt-0">
                <div class="row">

                    <div class="col-sm-8">
                        <div class="pt-4">

                            <div class="row">
                                <div class="col-6">
                                    <h5 class="font-size-15"><?php echo e($customer->MeterNumber); ?></h5>
                                    <p class="text-muted mb-0">Meter Number</p>
                                </div>
                                <div class="col-6">
                                    <h5 class="font-size-15"><?php echo e($customer->ConnectionType); ?></h5>
                                    <p class="text-muted mb-0">Connection Type</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end card -->
        <?php if(!$customer->account == null): ?>
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-4">Account Credentials</h4>
                    <div class="table-responsive">
                        <table class="table table-nowrap mb-0">
                            <tbody>
                                <tr>
                                    <th scope="row">Username</th>
                                    <th>:</th>
                                    <td><?php echo e($customer->account->username); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Mobile</th>
                                    <th>:</th>
                                    <td><?php echo e($customer->account->ContactNumber); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">E-mail</th>
                                    <th>:</th>
                                    <td><?php echo e($customer->account->email); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- end card -->
        <?php endif; ?>
    </div>

    <div class="col-xl-8">

        <div class="row">
            <div class="col-md-3">
                <div class="card mini-stats-wid">
                    <div class="card-body bg-danger">
                        <div class="d-flex">
                            <div class="flex-grow-1">
                                <p class="text-white fw-medium mb-2">Present Reading (Current)</p>
                                <h4 class="mb-0 text-end text-white"><?php echo e(number_format($currentBilling->PresentReading, 2, '.', ',')); ?> kw</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card mini-stats-wid">
                    <div class="card-body bg-danger">
                        <div class="d-flex">
                            <div class="flex-grow-1">
                                <p class="text-white fw-medium mb-2">Previous Reading (Current)</p>
                                <h4 class="mb-0 text-end text-white"><?php echo e(number_format($currentBilling->PreviousReading, 2, '.', ',')); ?> kw</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card mini-stats-wid">
                    <div class="card-body bg-danger">
                        <div class="d-flex">
                            <div class="flex-grow-1">
                                <p class="text-white fw-medium mb-2">KILOWATT USED (Current)</p>
                                <h4 class="mb-0 text-end text-white"><?php echo e(number_format($currentBilling->KiloWattsUsed, 2, '.', ',')); ?> kw</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card mini-stats-wid">
                    <div class="card-body bg-warning bg-soft">
                        <div class="d-flex">
                            <div class="flex-grow-1">
                                <p class="text-muted fw-medium mb-2">Total Bill (Current)</p>
                                <h4 class="mb-0 text-end fw-bold"> &#8369; <?php echo e(number_format($currentBilling->TotalBill, 2, '.', ',')); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card h-100">
            <div class="card-body">
                <h4 class="card-title mb-4">Previous Billings</h4>
                <div class="table-responsive">
                    <table class="table table-nowrap table-hover mb-0">
                        <thead class="table-primary">
                            <tr>
                                <th class="text-start">Billing Date</th>
                                <th class="text-center">Present Reading</th>
                                <th class="text-center">Previous Reading</th>
                                <th class="text-center">Kilo Watts Used</th>
                                <th class="text-center">Total Bill</th>
                                <th class="text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $otherBilling; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherBillings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-start"> <?php echo e(Carbon\Carbon::parse($otherBillings->BillingPeriodFrom)->format('F d')); ?> - <?php echo e(Carbon\Carbon::parse($otherBillings->BillingPeriodTo)->format('F d, Y')); ?> </td>
                                    <td class="text-center"> <?php echo e(number_format($otherBillings->PresentReading, 2, '.', ',')); ?> </td>
                                    <td class="text-center"> <?php echo e(number_format($otherBillings->PreviousReading, 2, '.', ',')); ?> </td>
                                    <td class="text-center"> <?php echo e(number_format($otherBillings->KiloWattsUsed, 2, '.', ',')); ?> </td>
                                    <td class="text-center fw-bold"> <?php echo e(number_format($otherBillings->TotalBill, 2, '.', ',')); ?> </td>
                                    <td class="text-center"> <span class="badge badge-pill badge-soft-success font-size-11"><?php echo e($otherBillings->BillingStatus == 1 ? 'Paid' : 'Pending'); ?></span> </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- end row -->
</div>
<?php $__env->startPush('page-scripts'); ?>
    <script src="<?php echo e(asset('/assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/libs/winbox/winbox.bundle.js')); ?>"></script>
    <script>
        $(function(){

        });
    </script>
<?php $__env->stopPush(); ?>
<!-- end row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.winbox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sursecoOnlineBilling\resources\views/admin-customer-billings.blade.php ENDPATH**/ ?>