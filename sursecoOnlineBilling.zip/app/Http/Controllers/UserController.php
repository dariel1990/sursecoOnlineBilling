<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\User;
use Illuminate\Http\Request;
use App\Models\CustomerBilling;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Auth;
use App\Models\CustomerBillingTransactions;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'verified']);
    }

    public function index()
    {
        $user = User::with(['customer', 'customer.customerBilling', 'customer.customerBilling.customerBillTransaction'])->where('id', Auth::user()->id)->first();
        $latestBill = $user->customer->customerBilling()->where('BillingStatus', 0)->first()->TotalBill;
        $periodFrom = Carbon::parse($user->customer->customerBilling()->where('BillingStatus', 0)->first()->BillingPeriodFrom)->format('M d');
        $periodTo = Carbon::parse($user->customer->customerBilling()->where('BillingStatus', 0)->first()->BillingPeriodTo)->format('M d, Y');
        $currentKwUsed = $user->customer->customerBilling()->where('BillingStatus', 0)->first()->KiloWattsUsed;

        $currentBilling = CustomerBilling::whereMonth('BillingPeriodTo', '=', Carbon::now()->month)->where('CustomerId', Auth::user()->id)->first();
        $otherBilling = CustomerBilling::whereNotIn('id', [$currentBilling->id])->where('CustomerId', Auth::user()->id)->orderBy('BillingPeriodFrom', 'DESC')->get();
        // dd($latestBill);
        return view('user-home', compact('user', 'latestBill', 'periodFrom', 'periodTo', 'currentKwUsed', 'currentBilling', 'otherBilling'));
    }

}
